#include "gtest/gtest.h"
// #include "gmock/gmock.h"
#include "hw1.h"
#include <iostream>

int main (int argc, char *argv[]) {
    ::testing::InitGoogleTest(&argc, argv);
    std::cout << RUN_ALL_TESTS() << std::endl;
    // std::cout<<"this is result : "<< (read_csv())[1]->at(1)<<std::endl<<"the rest :"<<std::endl;
    std::vector<std::shared_ptr<std::vector<double>>> train_data{read_csv("data.csv")};
    std::vector<std::shared_ptr<std::vector<double>>> original_data{read_csv("data.csv")};
    std::vector<double> info {train(train_data,0.1,100)};
    int acc {predict(original_data,info[0],info[1],info[2],info[3])};
    accuracy(acc);
}